import json
from datetime import datetime, timedelta

CREDITS_FILE = "credits.json"
DAILY_CREDITS = 1  # Daily credit is now 1

def load_credits():
    try:
        with open(CREDITS_FILE, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def save_credits(data):
    with open(CREDITS_FILE, "w") as f:
        json.dump(data, f, indent=4)

def get_today_str():
    bd_time = datetime.utcnow() + timedelta(hours=6)  # Bangladesh time
    return bd_time.strftime("%Y-%m-%d")

def get_user_credits(user_id):
    data = load_credits()
    today = get_today_str()
    user_data = data.get(str(user_id), {"credits": DAILY_CREDITS, "last_reset": today})

    if user_data["last_reset"] != today:
        # Reset credits if they are <= DAILY_CREDITS
        if user_data["credits"] <= DAILY_CREDITS:
            user_data["credits"] = DAILY_CREDITS
        # Don't reset for users with more than DAILY_CREDITS
        user_data["last_reset"] = today
        data[str(user_id)] = user_data
        save_credits(data)

    return user_data["credits"]

def decrement_credit(user_id):
    data = load_credits()
    today = get_today_str()
    user_id = str(user_id)

    if user_id not in data or data[user_id]["last_reset"] != today:
        data[user_id] = {"credits": DAILY_CREDITS - 1, "last_reset": today}
    else:
        data[user_id]["credits"] = max(0, data[user_id]["credits"] - 1)

    save_credits(data)

def set_user_credits(user_id, amount):
    data = load_credits()
    today = get_today_str()
    data[str(user_id)] = {"credits": amount, "last_reset": today}
    save_credits(data)