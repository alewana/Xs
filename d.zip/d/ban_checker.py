import discord
import aiohttp

API_URL = "https://jamibancheckerapi.vercel.app/check"

async def check_ban(interaction: discord.Interaction, uid: str):
    await interaction.response.defer(thinking=True)

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{API_URL}?uid={uid}") as resp:
                if resp.status != 200:
                    embed = discord.Embed(
                        title="Player Not Found",
                        description=f"{interaction.user.mention}, no player found with UID `{uid}`.",
                        color=0xED4245
                    )
                    embed.set_footer(text="CYBER CRACKS's Creation   Dev  CYBER CRACKS")
                    await interaction.followup.send(embed=embed)
                    return

                data = await resp.json()
                nickname = data.get("nickname", "N/A")
                region = data.get("region", "N/A")
                is_banned = str(data.get("ban_status")).lower() == "true"
                ban_period = data.get("ban_period") or "N/A"

                title = "Player Banned" if is_banned else "Player Not Banned"
                color = 0xE87EBF if is_banned else 0x66FFA3
                status = "Banned" if is_banned else "Not Banned"

                description = (
                    f"{interaction.user.mention}, Here is the ban status of the player\n\n"
                    f"**Player Nickname:** {nickname}\n"
                    f"**Geographic Region:** {region}\n"
                    f"**Account Status:** {status}\n"
                    f"**Restriction Duration:** {ban_period}"
                )

                embed = discord.Embed(title=title, description=description, color=color)
                embed.set_image(url="https://github.com/khan-khan12/irfanxiters/blob/main/standard%20(2).gif?raw=true")
                embed.set_footer(text="Irfan Managar")
                await interaction.followup.send(embed=embed)

    except Exception:
        embed = discord.Embed(
            title="⚠️ Error",
            description="An error occurred while processing your request.",
            color=0xFFA500
        )
        embed.set_footer(text="IRFAN Creation   Dev IrfanXiters")
        await interaction.followup.send(embed=embed)
