import discord
from discord import app_commands
from discord.ext import commands
import asyncio
import json
import credits
import admin
import autolike
import autoupdate
import info
from ban_checker import check_ban
import itertools
from discord.ext import commands, tasks
from regionget import get_region

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="/", intents=intents)
tree = bot.tree

TOKEN = "MTQwMjYyMDM2MTE5NTEyNjkyNQ.GwCzYB.1OjO2YTAjI1oOjuoaSzh3uCV-RnN12IXehV1t4"

IMAGE_URL = "https://github.com/khan-khan12/irfanxiters/blob/main/standard%20(2).gif?raw=true"
FOOTER_TEXT = "Irfan Manager"

@tasks.loop(seconds=5)  # Updates every 5 seconds
async def update_status():
    guild_count = len(bot.guilds)  # Get the number of servers the bot is in
    
    statuses = [
        discord.CustomActivity(name="Executing Ban Verification Protocol"),
        discord.CustomActivity(name="Scanning UID Records"),
        discord.CustomActivity(name="Enforcing Anti-Abuse Measures"),
        discord.CustomActivity(name=f"Monitoring {guild_count} Servers"),
        discord.CustomActivity(name="Synchronizing Game Database"),
        discord.CustomActivity(name="Analyzing Player Activity Logs")
    ]
    
    # Rotate through statuses based on loop count
    index = update_status.current_loop % len(statuses)
    await bot.change_presence(activity=statuses[index])

    
    
def build_embed(title, description, color):
    embed = discord.Embed(title=title, description=description, color=color)
    embed.set_footer(text=FOOTER_TEXT)
    embed.set_image(url=IMAGE_URL)
    return embed

def load_channel_file(filename):
    try:
        with open(filename, "r") as f:
            return json.load(f)
    except:
        return []

def save_channel_file(filename, data):
    with open(filename, "w") as f:
        json.dump(data, f, indent=4)

def is_allowed_channel(channel_id, filename):
    return channel_id in load_channel_file(filename)

def add_channel(channel_id, filename):
    data = load_channel_file(filename)
    if channel_id not in data:
        data.append(channel_id)
        save_channel_file(filename, data)
        return True
    return False

def remove_channel(channel_id, filename):
    data = load_channel_file(filename)
    if channel_id in data:
        data.remove(channel_id)
        save_channel_file(filename, data)
        return True
    return False

@bot.event
async def on_ready():
    print(f"✅ Logged in as {bot.user}")
    update_status.start()
    await autoupdate.register_autoupdate_command(bot)
    await tree.sync()
    
    autolike_task = autolike.setup_autolike_task(bot, 1399326971338428426)
    
    if not autolike_task.is_running():
        autolike_task.start()






@tree.command(name="like", description="Send like request")
@app_commands.describe(uid="Player UID", server="Server")
@app_commands.choices(server=[
    app_commands.Choice(name="Asia Global", value="BD"),
    app_commands.Choice(name="India", value="IND"),
])
async def like(interaction: discord.Interaction, uid: str, server: app_commands.Choice[str]):
    if not is_allowed_channel(interaction.channel.id, "likechannel.json"):
        await interaction.response.send_message("🚫 Channel not allowed.", ephemeral=True)
        return
    if not uid.isdigit():
        await interaction.response.send_message("❌ UID must be numbers.", ephemeral=True)
        return

    user_id = interaction.user.id
    await interaction.response.defer()

    current_credits = credits.get_user_credits(user_id)
    if current_credits <= 0:
        await interaction.followup.send(
            f"**<@{user_id}>, ⏱ You've used your max allowed credits for today. To Buy Credits Visit Here <#1393481432558469172> Or Contact Owner <@1399374740375994380>**",
            ephemeral=True
        )
        return

    response = await autolike.call_api(server.value, uid)
    if response == "API_ERROR" or not isinstance(response, dict):
        await interaction.followup.send(
            embed=build_embed("Like Request Failed", f"<@{user_id}>, Unable to complete the request—please try again later.", 0xE87EBF)
        )
        return

    before = response.get("LikesbeforeCommand", "0")
    after = response.get("LikesafterCommand", "0")
    added = int(after) - int(before)

    if response.get("status") == 1 and added > 0:
        credits.decrement_credit(user_id)
        updated_credits = credits.get_user_credits(user_id)

        region = get_region(uid)  # from regionget.py

        embed = build_embed(
            " IrfanXiters",
            f"**<@{user_id}>, your like request has been processed successfully.**\n\n"
            f"**Player Nickname:** {response.get('PlayerNickname')}\n"
            f"**Geographic Region:** {region}\n"
            f"**Previous Count:** {before}\n"
            f"**Updated Count:** {after}\n"
            f"**Total Added:** You got {added} like(s) in your id **{response.get('UID', uid)}.**\n"
            f"**Credits Left:** You have {updated_credits} credits remaining.",
            0x66FFA3
        )
        await interaction.followup.send(embed=embed)
    else:
        updated_credits = credits.get_user_credits(user_id)
        embed = build_embed(
            "Max Likes Reached",
            f"<@{user_id}>, You've already reached the daily like limit for this UID.\n\n"
            f"**Credits Left:** You have {updated_credits} credits remaining.",
            0xefe6c6
        )
        await interaction.followup.send(embed=embed)

@tree.command(name="get", description="Fetch Free Fire UID profile")
@app_commands.describe(uid="Enter the Free Fire UID")
async def get(interaction: discord.Interaction, uid: str):
    if not is_allowed_channel(interaction.channel.id, "infochannel.json"):
        await interaction.response.send_message("🚫 Channel not allowed for this command Kindly Contact <@1399374740375994380>.", ephemeral=True)
        return
    if not uid.isdigit():
        await interaction.response.send_message("❌ UID must be numbers only.", ephemeral=True)
        return
    await info.get_profile_logic(interaction, uid)

@tree.command(name="check", description="Check if a Free Fire UID is banned")
@app_commands.describe(uid="Enter the Free Fire UID")
async def check(interaction: discord.Interaction, uid: str):
    if not is_allowed_channel(interaction.channel.id, "checkchannel.json"):
        await interaction.response.send_message("🚫 Channel not allowed for this command Kindly Contact <@1399374740375994380>.", ephemeral=True)
        return
    if not uid.isdigit():
        await interaction.response.send_message("❌ UID must be numbers only.", ephemeral=True)
        return
    await check_ban(interaction, uid)

@tree.command(name="admin", description="All admin controls in one command")
@app_commands.describe(
    choice="Choose an admin action",
    user="Target user (if applicable)",
    amount="Credit amount (for credits option)",
    type="Command type (for channelset)",
    channel="Channel (for channelset)",
    uid="UID (for autolike add/remove)",
    region="Region (for autolike add/remove)"
)
@app_commands.choices(
    choice=[
        app_commands.Choice(name="Add Admin", value="add_admin"),
        app_commands.Choice(name="Remove Admin", value="remove_admin"),
        app_commands.Choice(name="Set Credits", value="credits"),
        app_commands.Choice(name="Channel Add", value="channel_add"),
        app_commands.Choice(name="Channel Remove", value="channel_remove"),
        app_commands.Choice(name="Add AutoLike UID", value="autolike_add"),
        app_commands.Choice(name="Remove AutoLike UID", value="autolike_remove"),
        app_commands.Choice(name="List AutoLike", value="autolike_list")
    ],
    type=[
        app_commands.Choice(name="Like", value="likechannel.json"),
        app_commands.Choice(name="Info", value="infochannel.json"),
        app_commands.Choice(name="Check", value="checkchannel.json")
    ],
    region=[
        app_commands.Choice(name="Asia Global", value="BD"),
        app_commands.Choice(name="India", value="IND")
    ]
)
async def admin_all(
    interaction: discord.Interaction,
    choice: app_commands.Choice[str],
    user: discord.User = None,
    amount: int = None,
    type: app_commands.Choice[str] = None,
    channel: discord.TextChannel = None,
    uid: str = None,
    region: app_commands.Choice[str] = None
):
    if not admin.is_admin(interaction.user.id):
        await interaction.response.send_message(embed=build_embed("Access Denied", "🚫 Admin only Kindly Contact <@1309780637200416811>.", 0xE74C3C), ephemeral=False)
        return

    match choice.value:
        case "add_admin":
            if admin.add_admin(user.id):
                await interaction.response.send_message(embed=build_embed("Added", f"✅ {user.mention} is now admin.", 0x2ECC71), ephemeral=False)
            else:
                await interaction.response.send_message(embed=build_embed("Already", f"ℹ️ {user.mention} is already admin.", 0x3498DB), ephemeral=False)

        case "remove_admin":
            if admin.remove_admin(user.id):
                await interaction.response.send_message(embed=build_embed("Removed", f"✅ {user.mention} removed.", 0x2ECC71), ephemeral=False)
            else:
                await interaction.response.send_message(embed=build_embed("Not Admin", f"ℹ️ {user.mention} was not admin.", 0xF39C12), ephemeral=False)

        case "credits":
            credits.set_user_credits(user.id, amount)
            await interaction.response.send_message(embed=build_embed("Success", f"✅ Set {amount} credits for {user.mention}.", 0x2ECC71), ephemeral=False)

        case "channel_add":
            if add_channel(channel.id, type.value):
                await interaction.response.send_message(embed=build_embed("Added", f"✅ {channel.mention} added to `{type.value}`.", 0x2ECC71), ephemeral=False)
            else:
                await interaction.response.send_message(embed=build_embed("Exists", "ℹ️ Channel already allowed.", 0x3498DB), ephemeral=False)

        case "channel_remove":
            if remove_channel(channel.id, type.value):
                await interaction.response.send_message(embed=build_embed("Removed", f"✅ {channel.mention} removed from `{type.value}`.", 0x2ECC71), ephemeral=False)
            else:
                await interaction.response.send_message(embed=build_embed("Missing", "⚠️ Channel not in list.", 0xF1C40F), ephemeral=False)

        case "autolike_add":
            if not uid or not region:
                await interaction.response.send_message("❌ UID এবং Region অবশ্যই দিতে হবে যখন Add বা Remove করবা!", ephemeral=False)
                return
            success = autolike.add_scheduled_like(uid, region.value, interaction.user.id)
            if success:
                await interaction.response.send_message(f"✅ UID `{uid}` added for auto-like in region `{region.value}`.", ephemeral=False)
            else:
                await interaction.response.send_message(f"ℹ️ UID `{uid}` already scheduled for region `{region.value}`.", ephemeral=False)

        case "autolike_remove":
            if not uid or not region:
                await interaction.response.send_message("❌ UID এবং Region অবশ্যই দিতে হবে যখন Add বা Remove করবা!", ephemeral=False)
                return
            success = autolike.remove_scheduled_like(uid, region.value)
            if success:
                await interaction.response.send_message(f"✅ UID `{uid}` removed from auto-like list in region `{region.value}`.", ephemeral=False)
            else:
                await interaction.response.send_message(f"⚠️ UID `{uid}` was not in the list for region `{region.value}`.", ephemeral=False)

        case "autolike_list":
            data = autolike.load_autolike_data()
            if not data:
                await interaction.response.send_message("ℹ️ No UIDs currently scheduled for auto-like.", ephemeral=False)
                return
            description = ""
            for i, entry in enumerate(data, 1):
                user = f"<@{entry['user_id']}>" if entry.get("user_id") else "Unknown"
                description += f"**{i}.** UID: `{entry['uid']}`, Region: `{entry['region']}`, Requested by: {user}\n"
            embed = discord.Embed(
                title="📋 AutoLike Scheduled List",
                description=description,
                color=0x00FFFF
            )
            await interaction.response.send_message(embed=embed, ephemeral=False)


@bot.event
async def on_message(message):
    if message.author.bot:
        return

    content = message.content.strip()
    parts = content.split()

    class FakeResponse:
        async def defer(self, *args, **kwargs):
            pass
        async def send_message(self, content=None, embed=None, ephemeral=False):
            if embed:
                await message.reply(embed=embed)
            elif content:
                await message.reply(content)

    class FakeFollowup:
        async def send(self, content=None, embed=None, ephemeral=False):
            if embed:
                await message.reply(embed=embed)
            elif content:
                await message.reply(content)

    class FakeInteraction:
        def __init__(self, message):
            self.user = message.author
            self.channel = message.channel
            self.response = FakeResponse()
            self.followup = FakeFollowup()

    try:
        # LIKE command: like <uid> <region>
        if len(parts) == 3 and parts[0].lower() == "like" and parts[1].isdigit():
            region_code = parts[2].upper()

            allowed_regions = {
                "IND", "ID", "BR", "TH", "VN", "SG", "MY", "PH",
                "EU", "RU", "MENA", "PK", "US", "CA", "MX", "AR", "CL", "TW", "BD"
            }

            if region_code not in allowed_regions:
                await message.reply(f"🚫 Invalid region code `{region_code}`.")
                return

            # IND stays IND, all others treated as BD internally
            region_value = "IND" if region_code == "IND" else "BD"
            region = app_commands.Choice(name=region_code, value=region_value)

            if not is_allowed_channel(message.channel.id, "likechannel.json"):
                await message.reply("🚫 This channel is not allowed to use the **like** command Kindly Contact <@1309780637200416811>.")
                return

            processing_msg = await message.reply("⏳ Processing your like request... Please wait.")
            await asyncio.sleep(6)
            await processing_msg.delete()

            fake_interaction = FakeInteraction(message)
            await like.callback(fake_interaction, parts[1], region)

        # GET command: get <uid>
        elif len(parts) == 2 and parts[0].lower() == "get" and parts[1].isdigit():
            uid = parts[1]

            if not is_allowed_channel(message.channel.id, "infochannel.json"):
                await message.reply("🚫 This channel is not allowed to use the **get** command Kindly Contact <@1309780637200416811>.")
                return

            processing_msg = await message.reply("⏳ Fetching player info... Please wait.")
            await asyncio.sleep(6)
            await processing_msg.delete()

            fake_interaction = FakeInteraction(message)
            await info.get_profile_logic(fake_interaction, uid)

        # CHECK command: check <uid>
        elif len(parts) == 2 and parts[0].lower() == "check" and parts[1].isdigit():
            uid = parts[1]

            if not is_allowed_channel(message.channel.id, "checkchannel.json"):
                await message.reply("🚫 This channel is not allowed to use the **check** command Kindly Contact <@1309780637200416811>.")
                return

            processing_msg = await message.reply("⏳ Checking ban status... Please wait.")
            await asyncio.sleep(3)
            await processing_msg.delete()

            fake_interaction = FakeInteraction(message)
            await check.callback(fake_interaction, uid)

        # HELP command
        elif content.lower() == "help":
            embed = discord.Embed(
                title="Irfan Manager — Complete Help & Tutorial",
                description=(
                    "Welcome to **IrfanXiters** — your all-in-one Free Fire assistant! 🚀\n"
                    "This guide includes **normal text commands** (prefix‑free), **slash commands**, and detailed region info."
                ),
                color=0x2F3136
            )
            
            embed.set_footer(text=FOOTER_TEXT)        # Your footer text
            embed.set_image(url=IMAGE_URL)             # Banner or logo URL

            embed.add_field(
                name="💬 Text Commands (no prefix)",
                value=(
                    "like <UID> <REGION_CODE> → Send likes.\n"
                    "get <UID> → Fetch UID profile info.\n"
                    "check <UID> → Verify if UID is banned.\n"
                    "guestextract <uploaded_zip> → Extract guest account data."
                ),
                inline=False
            )

            embed.add_field(
                name="💻 Slash Commands",
                value=(
                    "/like <UID> <Region> → Send like request.\n"
                    "/get <UID> → Fetch UID profile info.\n"
                    "/check <UID> → Check for bans.\n"
                    "/guestextract → Upload a ZIP to extract guest data.\n"
                    "/admin → All admin controls (Add/Remove admin, credit settings, channel management, auto‑like UIDs).\n"
                    "/jwt → Generate JWT token.\n"
                    "/autoupdate → Sync bot with latest features."
                ),
                inline=False
            )

            embed.add_field(
                name="🌍 Supported Regions",
                value=(
                    "If you type **IND**, it’s handled as **India**.\n"
                    "All other codes below are processed as **Bangladesh & Other All Server** region:\n\n"
                    "ID, BD, BR, TH, VN, SG, MY, PH, EU, RU, MENA,\n"
                    "PK, US, CA, MX, AR, CL, TW\n\n"
                    "Examples:\n"
                    "like 123456789 IND → India like request\n"
                    "like 987654321 BD → Treated as Bangladesh region"
                ),
                inline=False
            )

            embed.add_field(
                name="📘 Quick Tutorial",
                value=(
                    "1. Open an allowed channel.\n"
                    "2. Type help (no slash, no prefix) → for this menu.\n"
                    "3. To like → like 123456789 ID or /like 123456789 BD.\n"
                    "4. To check profile/bans → get 123456789, check 123456789, or use slash.\n"
                   
                ),
                inline=False
            )

            embed.add_field(
                name="✳️ Pro Tips & Notes",
                value=(
                    "• Commands only work in **allowed channels**.\n"
                    "• Use **text commands** for quick access without slash.\n"
                    "• Use **slash commands** for guided input and autocomplete.\n"
                    "• Need help or access? Tag an admin or use /admin."
                ),
                inline=False
            )

            await message.reply(embed=embed)
            return

    except Exception as e:
        await message.reply(f"⚠️ Oops, something went wrong! Error: {str(e)[:150]}")

    await bot.process_commands(message)





bot.run(TOKEN)
