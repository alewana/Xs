# info.py
import discord
import requests
from datetime import datetime

def format_time(ts):
    try:
        return datetime.fromtimestamp(int(ts)).strftime('%Y-%m-%d %H:%M:%S')
    except:
        return "N/A"

async def get_profile_logic(interaction: discord.Interaction, uid: str):
    await interaction.response.defer()

    url = f"https://jamiinfoapi.vercel.app/player-info?uid={uid}"
    response = requests.get(url)

    if response.status_code != 200:
        await interaction.followup.send("❌ Failed to fetch profile. Invalid UID or server error.")
        return

    try:
        data = response.json()
        basic = data.get("basicInfo", {})
        profile = data.get("profileInfo", {})
        pet = data.get("petInfo", {})
        clan = data.get("clanBasicInfo", {})
        captain = data.get("captainBasicInfo", {})
        social = data.get("socialInfo", {})
        credit = data.get("creditScoreInfo", {})

        nickname = basic.get("nickname", "N/A")
        level = basic.get("level", "N/A")
        exp = basic.get("exp", "N/A")
        region = basic.get("region", "N/A")
        likes = basic.get("liked", "N/A")
        honor = credit.get("creditScore", "N/A")
        signature = social.get("signature", "N/A")
        release = basic.get("releaseVersion", "N/A")
        bp = basic.get("badgeCnt", "N/A")
        br = basic.get("rankingPoints", "N/A")
        cs = basic.get("csRankingPoints", "N/A")
        created = format_time(basic.get("createAt"))
        login = format_time(basic.get("lastLoginAt"))

        pet_name = pet.get("name", "N/A")
        pet_exp = pet.get("exp", "N/A")
        pet_level = pet.get("level", "N/A")
        pet_equipped = "Yes" if pet.get("isSelected") else "No"

        clan_name = clan.get("clanName", "N/A")
        clan_id = clan.get("clanId", "N/A")
        clan_level = clan.get("clanLevel", "N/A")
        clan_members = clan.get("memberNum", "N/A")

        leader_name = captain.get("nickname", "N/A")
        leader_uid = captain.get("accountId", "N/A")
        leader_level = captain.get("level", "N/A")
        leader_exp = captain.get("exp", "N/A")
        leader_created = format_time(captain.get("createAt"))
        leader_login = format_time(captain.get("lastLoginAt"))
        leader_br = captain.get("rankingPoints", "N/A")
        leader_cs = captain.get("csRankingPoints", "N/A")

        embed = discord.Embed(
            title=f"{nickname} • The Ultimate Survivor",
            description=f"""**Account Basic Info**
**------------------------------------------**
**Name:** {nickname}
**UID:** {uid}
**Level:** {level} (Exp: {exp})
**Region:** {region}
**Likes:** {likes}
**Honor Score:** {honor}
**Signature:** {signature}
**------------------------------------------**
**Account Activity**
**Most Recent OB:** {release}
**Current BP Badges:** {bp}
**BR Rank Points:** {br}
**CS Rank Points:** {cs}
**Created At:** {created}
**Last Login:** {login}
**------------------------------------------**
**Pet Details**
**Equipped:** {pet_equipped}
**Pet Name:** {pet_name}
**Pet Exp:** {pet_exp}
**Pet Level:** {pet_level}
**------------------------------------------**
**Guild Info**
**Guild Name:** {clan_name}
**Guild ID:** {clan_id}
**Guild Level:** {clan_level}
**Live Members:** {clan_members}
**------------------------------------------**
**Leader Info**
**Leader Name:** {leader_name}
**Leader UID:** {leader_uid}
**Leader Level:** {leader_level} (Exp: {leader_exp})
**Leader Created At:** {leader_created}
**Leader Last Login:** {leader_login}
**Leader BR Points:** {leader_br}
**Leader CS Points:** {leader_cs}
**------------------------------------------**""",
            color=discord.Color.from_rgb(102, 255, 163)
        )

        embed.set_image(url=f"https://genprofile.vercel.app/generate?uid={uid}")
        embed.set_footer(text="Irfan Managar")

        await interaction.followup.send(embed=embed)

    except Exception as e:
        await interaction.followup.send(f"⚠️ Error while processing data: `{e}`")
