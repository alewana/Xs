import requests

def get_region(uid: str) -> str:
    try:
        url = f"https://jamiinfoapi.vercel.app/player-info?uid={uid}"
        response = requests.get(url)
        if response.status_code != 200:
            return "Unknown"
        data = response.json()
        return data.get("basicInfo", {}).get("region", "Unknown")
    except Exception as e:
        print(f"[ERROR] Failed to get region for UID {uid}: {e}")
        return "Unknown"
