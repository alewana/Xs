import json
import asyncio
from discord.ext import tasks
from datetime import datetime, timedelta
import aiohttp
import discord
from regionget import get_region

AUTOLIKE_FILE = "autolike.json"

def load_autolike_data():
    try:
        with open(AUTOLIKE_FILE, "r") as f:
            content = f.read().strip()
            if not content:
                return []
            return json.loads(content)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_autolike_data(data):
    with open(AUTOLIKE_FILE, "w") as f:
        json.dump(data, f, indent=4)

def add_scheduled_like(uid, region, user_id=None):
    data = load_autolike_data()
    if any(entry["uid"] == uid and entry["region"] == region for entry in data):
        return False
    data.append({"uid": uid, "region": region, "user_id": user_id})
    save_autolike_data(data)
    return True

def remove_scheduled_like(uid, region):
    data = load_autolike_data()
    new_data = [entry for entry in data if not (entry["uid"] == uid and entry["region"] == region)]
    if len(new_data) == len(data):
        return False
    save_autolike_data(new_data)
    return True

async def call_api(region, uid):
    url = f"https://jamilikebotapi.vercel.app/like?uid={uid}&server_name={region}"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=10) as resp:
                if resp.status != 200:
                    return "API_ERROR"
                data = await resp.json()
                return data
    except Exception:
        return "API_ERROR"

def gif_url():
    return "https://github.com/khan-khan12/irfanxiters/blob/main/standard%20(2).gif?raw=true"

def setup_autolike_task(bot, channel_id):
    @tasks.loop(minutes=1)
    async def autolike_task():
        now = datetime.utcnow() + timedelta(hours=6)  # BD time (UTC+6)
        if now.hour != 18 or now.minute != 1:
            return  # Not the scheduled time yet

        data = load_autolike_data()
        if not data:
            return

        channel = bot.get_channel(channel_id)
        if not channel:
            print("⚠️ Allowed channel not found for autolikes.")
            return

        for entry in data:
            uid = entry["uid"]
            region = entry["region"]
            user_id = entry.get("user_id")

            response = await call_api(region, uid)
            if response == "API_ERROR" or not isinstance(response, dict):
                print(f"Failed to send autolike for UID {uid} in region {region}")
                continue

            player_name = response.get('PlayerNickname', 'Unknown Player')
            likes_before = response.get('LikesbeforeCommand', '0')
            likes_after = response.get('LikesafterCommand', '0')
            likes_given = int(response.get('LikesGivenByAPI', 0))
            uid_response = response.get('UID', uid)

            embed = discord.Embed(color=0x66FFA3)
            embed.set_footer(text="CrackverZZ AutoLike System")
            embed.set_image(url=gif_url())
            regionautolike = get_region(uid)  # from regionget.py
            if response.get("status") == 1 and likes_given > 0:
                embed.description = (
                    f"✅ **Auto-like sent to {player_name}** (UID: `{uid_response}`) in region `{regionautolike}`.\n"
                    f"👍 Likes Before: `{likes_before}`\n"
                    f"👍 Likes After: `{likes_after}`\n"
                    f"✨ Likes Given: `{likes_given}`"
                )
                if user_id:
                    embed.description += f"\n👤 Requested by <@{user_id}>"
            else:
                embed.description = (
                    f"⚠️ No likes given to `{player_name}` (UID: `{uid_response}`) in region `{regionautolike}`.\n"
                    f"Reason: Max likes reached or error from panel."
                )
                if user_id:
                    embed.description += f"\n👤 Requested by <@{user_id}>"

            await channel.send(embed=embed)

    return autolike_task
