import discord
from discord.ext import tasks
from discord import app_commands, Embed
import json, re, base64, aiohttp, asyncio
from datetime import datetime
import requests

GITHUB_TOKEN = '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'
GITHUB_REPO = 'jamiffsystem/LikeBotApi'
AUTO_UPDATE_CHANNEL_ID = 1397225150394667118
GITHUB_API = 'https://api.github.com'

CONFIGS = [
    {"uid_file": "uid_bd.json", "github_file": "token_bd.json"},
    {"uid_file": "uid_ind.json", "github_file": "token_ind.json"},
]

def validate_github_token(token):
    return re.match(r'^ghp_[a-zA-Z0-9]{36}$', token)

def validate_repo_name(repo):
    return re.match(r'^[\w-]+/[\w.-]+$', repo)

def validate_file_path(path):
    return path.endswith('.json')

def validate_uid_json(data):
    return isinstance(data, list) and all('uid' in d and 'password' in d for d in data)

def get_user_email(token):
    try:
        r = requests.get(f'{GITHUB_API}/user/emails', headers={
            'Authorization': f'token {token}',
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'cZZ Bot'
        }, timeout=10)
        if r.ok:
            emails = r.json()
            for email in emails:
                if email.get('primary') and email.get('verified'):
                    return email['email']
            for email in emails:
                if email.get('verified'):
                    return email['email']
    except Exception:
        pass
    return 'user@users.noreply.github.com'

def update_github_file(token, repo, file_path, content, message):
    headers = {
        'Authorization': f'token {token}',
        'Accept': 'application/vnd.github.v3+json',
        'User-Agent': 'Czz Bot'
    }
    url = f'{GITHUB_API}/repos/{repo}/contents/{file_path}'
    try:
        resp = requests.get(url, headers=headers, timeout=10)
        if not resp.ok:
            return {'error': 'File not found'}
        sha = resp.json().get('sha')
        email = get_user_email(token)
        data = {
            'message': message,
            'content': base64.b64encode(content.encode()).decode(),
            'sha': sha,
            'branch': 'main',
            'committer': {'name': 'Czz Bot', 'email': email},
            'author': {'name': 'Czz Bot', 'email': email},
        }
        put = requests.put(url, headers=headers, json=data, timeout=10)
        return put.json()
    except Exception as e:
        print(f"❌ Exception updating GitHub file: {e}")
        return {'error': str(e)}

async def fetch_token_with_retry(session, uid, password, retries=5, delay=2):
    url = f'https://jamijwt.vercel.app/token?uid={uid}&password={password}'
    for attempt in range(1, retries + 1):
        try:
            async with session.get(url, timeout=10) as resp:
                data = await resp.json()
                if resp.status == 200 and data.get('status') != 'invalid':
                    token = data.get('token')
                    return token
                elif data.get('status') == 'invalid':
                    print(f"⚠️ Skipping UID {uid}: Wrong UID or Password.")
                    return None
        except Exception as e:
            print(f"⚠️ Attempt {attempt} failed for UID {uid}: {e}")
            if attempt < retries:
                await asyncio.sleep(delay)
    return None

async def generate_and_update_for(uid_file, github_file_path):
    if not (validate_github_token(GITHUB_TOKEN) and validate_repo_name(GITHUB_REPO) and validate_file_path(github_file_path)):
        print(f"❌ Invalid GitHub configuration for file: {github_file_path}")
        return (0, 0, True)

    try:
        with open(uid_file, 'r', encoding='utf-8') as f:
            creds = json.load(f)
    except Exception as e:
        print(f"❌ Failed to load UID file ({uid_file}): {e}")
        return (0, 0, True)

    if not validate_uid_json(creds):
        print(f"❌ Invalid UID data format in {uid_file}")
        return (0, 0, True)

    results, failed = [], []

    async with aiohttp.ClientSession() as session:
        batch_size = 10
        total = len(creds)
        for i in range(0, total, batch_size):
            batch = creds[i:i+batch_size]
            coros = [fetch_token_with_retry(session, entry['uid'], entry['password']) for entry in batch]
            tokens = await asyncio.gather(*coros)

            for idx, token in enumerate(tokens):
                uid = batch[idx]['uid']
                if token:
                    results.append({'uid': uid, 'token': token})
                else:
                    failed.append(uid)

    if results:
        response = update_github_file(
            GITHUB_TOKEN,
            GITHUB_REPO,
            github_file_path,
            json.dumps(results, indent=2),
            f'Update tokens for {uid_file} by Czz Bot'
        )
        error_flag = 'error' in response
        return (len(results), len(failed), error_flag)
    else:
        return (0, len(failed), False)

async def generate_and_update():
    total_success, total_failed, any_error = 0, 0, False
    for cfg in CONFIGS:
        success, failed, error = await generate_and_update_for(cfg["uid_file"], cfg["github_file"])
        total_success += success
        total_failed += failed
        any_error = any_error or error
    return (total_success, total_failed, any_error)

async def handle_auto_update(bot):
    success, failed, error = await generate_and_update()
    print(f"[Auto] Success: {success}, Failed: {failed}, Error: {error}")

    channel = bot.get_channel(AUTO_UPDATE_CHANNEL_ID)
    if channel:
        embed = Embed(title="🤖 Auto Update Report", color=0x5865F2, timestamp=datetime.utcnow())
        if error:
            embed.color = 0xe74c3c
            embed.description = "❌ An error occurred during auto update."
        else:
            embed.color = 0x2ecc71
            embed.description = (f"**Success:** `{success}` tokens updated\n"
                                 f"**Failed:** `{failed}` tokens failed\n"
                                 f"⏰ Time: `{datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC`")
        await channel.send(embed=embed)

bot_ref = None

@tasks.loop(minutes=420)

async def auto_updater():
    global bot_ref
    if bot_ref is None:
        print("❌ Bot reference not set, cannot auto update.")
        return
    await handle_auto_update(bot_ref)

@auto_updater.before_loop
async def before_auto_updater():
    global bot_ref
    while bot_ref is None:
        await asyncio.sleep(1)
    await bot_ref.wait_until_ready()

async def register_autoupdate_command(bot):
    global bot_ref
    bot_ref = bot

    @app_commands.command(name="refreshtoken", description="🔧 Setup/start/stop/manual JWT update")
    @app_commands.describe(action="Choose action")
    @app_commands.choices(action=[
        app_commands.Choice(name="Start Auto Update", value="start"),
        app_commands.Choice(name="Stop Auto Update", value="stop"),
        app_commands.Choice(name="Manual Update", value="generate")
    ])
    async def autoupdatejwt(interaction: discord.Interaction, action: app_commands.Choice[str]):
        # ✅ Restrict to multiple allowed user IDs
        allowed_user_ids = [1280802698437857346]
        if interaction.user.id not in allowed_user_ids:
            await interaction.response.send_message(
                "❌ You do not have permission to use this command.", ephemeral=True
            )
            return

        embed = Embed(title="CYBER CRACKS Control Panel", color=0x5865F2)
        embed.set_footer(text="Powered by CYBER")

        if action.value == "start":
            if not auto_updater.is_running():
                auto_updater.start()
                embed.description = "✅ Auto update started. Will run every 7 hours"
            else:
                embed.description = "⚠️ Auto update already running."
            await interaction.response.send_message(embed=embed, ephemeral=True)

        elif action.value == "stop":
            if auto_updater.is_running():
                auto_updater.cancel()
                embed.description = "✅ Auto update stopped."
            else:
                embed.description = "⚠️ Auto update is not running."
            await interaction.response.send_message(embed=embed, ephemeral=True)

        elif action.value == "generate":
            await interaction.response.defer(thinking=True)
            success, failed, error = await generate_and_update()
            embed.color = 0x2ecc71 if not error else 0xe74c3c
            if error:
                embed.description = "❌ An error occurred during update. Please check logs."
            else:
                embed.title = "✅ Token Update Summary"
                embed.description = (f"**Success:** `{success}`\n"
                                     f"**Failed:** `{failed}`\n"
                                     f"⏰ Time: `{datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC`")
            await interaction.followup.send(embed=embed, ephemeral=True)


    bot.tree.add_command(autoupdatejwt)
